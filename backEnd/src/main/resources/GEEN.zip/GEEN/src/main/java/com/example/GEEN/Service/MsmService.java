package com.example.GEEN.Service;

public interface MsmService {
    public Boolean send(String email, String title, String code);
}
