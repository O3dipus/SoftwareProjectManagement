package com.example.GEEN.Util;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author hello
 * @title: Cache
 * @projectName fitness-course-service
 * @description: TODO
 * @date 2021/5/1816:45
 */
public class Cache {
    private final static ConcurrentHashMap<String, List<String>> MAP = new ConcurrentHashMap<>();

    /**
     * 添加缓存
     */
    public synchronized static void put(String key, List<String> data) {
        //清除原键值对
        Cache.remove(key);
        //不设置过期时间
        MAP.put(key, data);
    }

    /**
     * 读取缓存
     */
    public static List<String> get(String key) {
        return MAP.get(key);
    }

    /**
     * 清除缓存
     */
    public synchronized static void remove(String key) {
        MAP.remove(key);
    }
}
